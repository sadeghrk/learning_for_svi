/**
 * Access to PEPA-to-PRISM model translation.
 */
package pepa.compiler;
