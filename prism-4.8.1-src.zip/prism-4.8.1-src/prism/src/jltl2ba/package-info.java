/**
 * Java port of the LTL to Buchi automata conversion library.
 */
package jltl2ba;
