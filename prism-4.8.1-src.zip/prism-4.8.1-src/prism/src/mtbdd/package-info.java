/**
 * Access to the "MTBDD" engine: fully symbolic implementations of model checking algorithms.
 */
package mtbdd;
