This case study is based on the flexible manufacturing system of [CT93].

For more information, see: http://www.prismmodelchecker.org/casestudies/fms.php

=====================================================================================

[CT93]
G. Ciardo and K.S. Trivedi
A decomposition approach for stochastic reward networks
Performance Evaluation, 18(1):37-59, 1993
